Functionality-5
The program is a basic notepad with functions like opening a given text file and saving a text file.
The extra function which has been added to it is a open reverse function
which opens the file in such a way that all the numbers are printed reversed 
for example 4567 is printed as 7654 and 67.54 is printed as 76.45.
In addition there is an inbuilt function to check whether you have changed the file OR not and if yes than it will ask to save it.

Reliability-5
The program is tested for various critical input values and it is reliable.
The program has been tested for the decimal values also.
Various exception checking statements are written to consider various failures in file handling.

Re-Usability-5
The program has been written in very simple and straight forward way and can be easily undertstood.
Names of the functions are appropriatly chosen.Tooltip has been used which explains the user the function 
of that item.The program is very user friendly with instructions given at each step to operate it.
Also this program can be reused to add functions like copy,paste and text formatting like font size etc.

Maintainability-4
All the items have their code defined in proper place and therefore it can be mantained easily.
Save action   function has been called in Exit item which is the only interconnection.

Efficiency-4
Almost all the functions used for opening,closing,saving the file and for reversing the numbers ar inbuilt java functions,therefore they are efficient.

Portability-5
A jar file is automatically generated in the project folder which can be directly clicked to run the application.
Also from caommand line the application can be run on any environment supported by java.


NOTE-Help was taken from netbeans.org regarding the filechooser.
               

