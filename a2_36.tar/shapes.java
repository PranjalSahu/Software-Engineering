
public interface shapes {
	    public String name();
        void draw();
        void intersect(shapes A);
}
