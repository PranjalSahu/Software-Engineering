0 means waiting at some branch
1 means transpoting

after o/1 name of branch is given
