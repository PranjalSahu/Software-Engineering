READ ME FILE FOR ASSGNMENT NO. 3	


1. Functionality- (5/5)
The program contains standard calculator functions to satisfy the user needs as well as functions like sin(x),cos(x),sin(a+b),cos(a+b),nCr,nPr,n!.
It also has a CLEAR and a BACKSPACE button for user's comfort.The program is very easy to operate.It is very intuitive also.Also for user's help a label in side os the screen has been given to explain the operation and for instructing the user to operate.Classes name and functions name are all self explanatory.Large and widely spaced buttons has been used.As per the frequency of usage the buttons has been placed.

2.Reliability-(5/5)
Every minute detail has been taken care of to avoid errors.Check conditions has been given for proper input.
Standard mathematical functions has been used for calculating the answer.

3.Re-usability-(3/5)
The program can be reused for extending functions.Code also can be reused but partly.


4.Efficiency-(4/5)
Since the program doesn't uses efficient algorithm for calculating n!,nCr and nPr therefore it is quite inefficient for larger values and errors may creep in.THEREFORE PLEASE INPUT SMALLER VALUES OF N AND R FOR THESE THREE FUNCTIONS.Since the assignment is to make a simple GUI calculator therefore emphasis on algorithm has not been given much.

5.Maintainability-(4/5)
This program can be extended further without much disturbing the present code.As per the requirement more buttons can be added.Single argument functions can be extended without any difficulty but for double or more argument functions modifications will have to be done in ANS button.Since a user may deliberately try to misuse a calculator by giving inappropriate input,therefore many if else statement has been used.

Portability-(5/5)
